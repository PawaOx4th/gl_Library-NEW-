package com.company;

import java.util.List;
import java.util.Scanner;

public class Add {
    public static void Addbook(List<Book>books){

        Book book_add = new Book();
        Scanner sb1 = new Scanner(System.in);
        System.out.print("Please enter book name : ");
        String bName = sb1.nextLine();
        System.out.println("Book name : " + bName);
        Scanner sb2 = new Scanner(System.in);
        System.out.print("Please enter book category : ");
        String bCat = sb1.nextLine();
        Bookcategory category = Bookcategory.valueOf(bCat);
        System.out.println("Book name : " + bCat);
        Scanner sb3 = new Scanner(System.in);
        System.out.print("Please enter book code : ");
        String bCode = sb1.nextLine();
        System.out.println("Book name : " + bCode);
        Scanner sb4 = new Scanner(System.in);


        book_add.bookname = bName;
        book_add.bookcategory = bCat;
        book_add.bookcode = bCode;
        book_add.bookstatus = Bookstatus.valueOf("BLANK") ;

        books.add(book_add);
        System.out.println("=====================");
        for (int i = 0; i < books.size(); i++) {
            System.out.println(books.get(i));
        }
        System.out.println("=====================");
    }
}
