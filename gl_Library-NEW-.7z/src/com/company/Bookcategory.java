package com.company;

public enum Bookcategory {

    News,History,Novel
}
