package com.company;
//import java.util.Scanner;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Iterator;
import java.io.FileWriter;
import java.util.*;

public class Main {

    public static Object Book;

    public static void main(String[] args) {

        //************************* Login Section *************************//
        Scanner pos = new Scanner(System.in);
        System.out.println("Please enter your position");
        System.out.println("1 - Administrator");
        System.out.println("2 - Employee");
        int ans_1 = pos.nextInt();

        //************************* Administrator Section *************************//

        if (ans_1 == 1) {
            boolean loop = true;
            Scanner want = new Scanner(System.in);
            List<Book> books = new ArrayList<>();
            //************************* Add Component *************************//
            do {
                System.out.println("\nWhat  do you want to do");
                System.out.println("1 - Add Book\t2 - Delete Book\t3 - Search\n" +
                        "4 - ChangStatus\t\t5 - Sort\t\t6 - Approve\n7 - Accept\t\t8 - Exit");
                int ans_2 = want.nextInt();
                switch (ans_2) {
                    //************************* Add Section *************************//
                    case 1:
                        Add a = new Add();
                        a.Addbook(books);
                        break;
                    case 2:
                        //************************* Remove Section *************************//
                        Remove d = new Remove();
                        Scanner dc = new Scanner(System.in);
                        System.out.println("\nPlease insert Book code to delete : ");
                        String id = dc.nextLine();
                        d.removebook(id, books);
                        d.show(books);
                        break;
                    case 3:
                        //************************* Search Section *************************//
                        Scanner sh = new Scanner(System.in);
                        System.out.println("Please enter book code : ");
                        String id2 = sh.nextLine();
                        Search S = new Search();
                        S.searchBook(id2, books);
                        break;
                    case 4:
                        Scanner ch = new Scanner(System.in);
                        System.out.println("Please input Book code to Chang Status");
                        String id3 = ch.nextLine();
                        ChangStatus Chang = new ChangStatus();
                        Chang.changStatus(id3,books);
                        break;
                    case 5:
                        break;
                    case 6:
                        break;
                    case 7:
                        break;
                    case 8:
                        //************************* Terminate Section *************************//
                        System.out.println("Thank you");
                        loop = false;
                }
            }
            while (loop);
        } else {
            if (ans_1 == 2) {
                //************************* Employee Section *************************//
                // List<Book> books = new ArrayList<>();
                boolean loop = true;
                Scanner want = new Scanner(System.in);
                //************************* Add Component *************************//

                do {
                    System.out.println("\nWhat  do you want to do");
                    System.out.println("1 - Search\n2 - Check\n3 - Rental\n4 - Return\n5-Exit");
                    int ans_2 = want.nextInt();
                    switch (ans_2) {
                        case 1:
                            break;
                        case 2:
                            break;
                        case 3:
                            break;
                        case 4:
                            break;

                        default:
                            loop = false;
                    }
                } while (loop);
            } else {
                System.out.println("Sorry please connect again later");
            }
        }
    }
}



