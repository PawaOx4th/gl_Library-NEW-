package com.company;

import java.util.Iterator;
import java.util.List;

public class Search {
    //************************* Search Component *************************//
    public static void searchBook(String id, List<Book> books){
        Iterator<Book> iterator = books.iterator();
        while (iterator.hasNext()){
            Book book = iterator.next();
            if (book.getBookcode().equals(id)){
                System.out.println("==========================");
                System.out.println("Book Name   : " +book.bookname);
                System.out.println("Book Type   : " +book.bookcategory);
                System.out.println("Book Code   : " +book.bookcode);
//                    System.out.println("Book Status : Exist");
                System.out.println("==========================");
            }
            else
            if (book.getBookcode().equalsIgnoreCase(id)){
                System.out.println("'Sorry your book is not exist to my Grouplease Library");
            }
        }
    }
}
