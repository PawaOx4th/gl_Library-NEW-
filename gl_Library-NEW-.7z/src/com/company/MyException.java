package com.company;

public class MyException extends Exception{

}
