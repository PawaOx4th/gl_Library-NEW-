package com.company;

public enum Bookstatus {

        BLANK,  //สามารถยืมได้
        BUSY;   //ไม่สามารถยืมได้


}
